# SteeringTweaker
Simple little mod that adds a "steering limiter" slider on wheels, to allow the player to reduce the steering range of the wheel (e.g. for stability on high-speed vehicles).

